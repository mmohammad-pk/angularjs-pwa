import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NavigationComponent } from './components/navigation/navigation.component';
import { FooterComponent } from './components/footer/footer.component';
import { LinechartComponent } from './components/linechart/linechart.component';
import { DoughnutChartComponent } from './components/doughnutchart/doughnut-chart.component';
import { FlexLayoutModule } from '@angular/flex-layout';
import { DashboardComponent } from './screens/dashboard/dashboard.component';
import { BarchartComponent } from './components/barchart/barchart.component';
import { AreaWiseAlarmComponent } from './screens/AreawiseAlarm/area-wise-alarm.component';
import { AlarmQuickViewComponent } from './screens/AlaramQuickView/alarm-quick-view.component';
import { AlarmlistComponent } from './components/alarmlist/alarmlist.component';
import { HttpClientModule } from '@angular/common/http';
import { DeviceComponent } from './components/device/device.component';

@NgModule({
  declarations: [
    AppComponent,
    NavigationComponent,
    FooterComponent,
    LinechartComponent,
    DoughnutChartComponent,
    DashboardComponent,
    BarchartComponent,
    AreaWiseAlarmComponent,
    AlarmQuickViewComponent,
    AlarmlistComponent,
    DeviceComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FlexLayoutModule,
    HttpClientModule

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
