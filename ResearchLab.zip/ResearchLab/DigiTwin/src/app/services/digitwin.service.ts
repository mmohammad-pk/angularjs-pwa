import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ITemprature, IAlarms, ICountries } from '../interface/temprature';
import { Observable, throwError } from 'rxjs';
import { retry, catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class DigitwinService {

  url = 'http://localhost:3000';
  //public deviceData;

  constructor(private http: HttpClient) { }

  getTemprature(): Observable<ITemprature> {
    return this.http.get<ITemprature>(this.url + '/temperature')
      .pipe(retry(1), catchError(this.handleError));
  }

  setDeviceData(deviceData) {
    sessionStorage.setItem('deviceData', JSON.stringify(deviceData));

  }
  getDeviceData() {
    return JSON.parse(sessionStorage.getItem('deviceData'));
  }


  // setDeviceData(deviceData) {
  //   this.deviceData = deviceData;
  // }

  // getDeviceData() {
  //   return this.deviceData;
  // }

  getAlarms(): Observable<IAlarms> {
    return this.http.get<IAlarms>(this.url + '/AlarmsData')
      .pipe(retry(1), catchError(this.handleError));
  }
  getCountries(): Observable<ICountries> {
    return this.http.get<ICountries>(this.url + '/Countries')
      .pipe(retry(1), catchError(this.handleError));
  }

  // Error handling 
  handleError(error) {
    let errorMessage = '';
    if (error.error instanceof ErrorEvent) {
      // Get client-side error
      errorMessage = error.error.message;
    } else {
      // Get server-side error
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
    window.alert(errorMessage);
    return throwError(errorMessage);
  }
}
