import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DashboardComponent } from './screens/dashboard/dashboard.component';
import { AreaWiseAlarmComponent } from './screens/AreawiseAlarm/area-wise-alarm.component';
import { AlarmQuickViewComponent } from './screens/AlaramQuickView/alarm-quick-view.component';

const routes: Routes = [
  { path: 'dashboard', component: DashboardComponent },
  { path: 'AreaWiseAlarms', component: AreaWiseAlarmComponent },
  { path: 'AlarmQuickView', component: AlarmQuickViewComponent },
  { path: '', redirectTo: '/dashboard', pathMatch: 'full' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
