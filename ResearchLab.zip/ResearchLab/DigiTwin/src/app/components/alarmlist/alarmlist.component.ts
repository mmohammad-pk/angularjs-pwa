import { Component, OnInit } from '@angular/core';
import { IAlarms } from 'src/app/interface/temprature';
import { DigitwinService } from 'src/app/services/digitwin.service';
@Component({
  selector: 'app-alarmlist',
  templateUrl: './alarmlist.component.html',
  styleUrls: ['./alarmlist.component.scss']
})
export class AlarmlistComponent implements OnInit {
  panelExpand = true;
  public alaramsData: IAlarms;
  constructor(private service: DigitwinService) { }
  ngOnInit() {
    this.ShowAlarams();
  }
  alaramToggle() {
    this.panelExpand = !this.panelExpand;
  }
  ShowAlarams() {
    this.service.getAlarms().subscribe(
      data => {
        this.alaramsData = data;
      }
    )
  }

}
