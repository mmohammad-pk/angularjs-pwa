import { Component, OnInit, Input, ElementRef, ViewChild } from '@angular/core';
import * as d3 from 'd3';
import * as chroma from 'chroma-js';
import { DigitwinService } from 'src/app/services/digitwin.service';
import { Subject } from 'rxjs';
import { isDifferent } from '@angular/core/src/render3/util';


@Component({
  selector: 'app-barchart',
  templateUrl: './barchart.component.html',
  styleUrls: ['./barchart.component.scss']
})
export class BarchartComponent implements OnInit {
  @ViewChild('barGraphchart') barGraphchart: ElementRef;

  public currentDataSet: Array<number> = [];

  @Input('graphId') graphId: number;

  @Input('graphwidth') graphwidth: number;

  @Input('graphheight') graphheight: number;

  @Input()
  set barGraphData(barGraphData: any) {
    //console.log(barGraphData);
    if (barGraphData && barGraphData.length > 0 && this.isDifferent(barGraphData)) {
      this.currentDataSet = barGraphData;
      this.initGraph(barGraphData);
      console.log("month", this.barGraphData);
    }
  }

  public temperatureText: any;
  public temperatureRect: any;
  constructor(private service: DigitwinService) {
  }

  ngOnInit() {

  }

  isDifferent(newData) {
    let isDifferent = false;
    newData.forEach((item, index) => {
      if (item !== this.currentDataSet[index]) {
        isDifferent = true;
        return;
      }
    });
    return isDifferent;
  }


  initGraph(dataset) {
    const w = this.graphwidth;
    const h = this.graphheight;
    // let dataset = this.barGraphData;
    // let dataset = [60, 65, 63, 50, 62, 69, 35];
    let colors = ['#b4ec51', '#53a0fd', '#3023ae'];
    let lineColor = "#b4ec51";
    let labelColor = "#fff";
    let labelFillColor = "#000000";
    let labelBorderColor = "#ffffff";

    //Init temperature labels
    let minWidthLabel = 40;
    let minHeightLabel = 20;
    let labelWidth = (w / dataset.length) * 0.50;
    let labelHeight = labelWidth * 0.40;
    let finalLabelWidth = labelWidth < minWidthLabel ? minWidthLabel : labelWidth;
    let finalLabelHeight = labelHeight < minHeightLabel ? minHeightLabel : labelHeight;
    let labelBarWidth = (w / dataset.length) * 0.30;
    let labelAdjustWidth = (finalLabelWidth - labelBarWidth) / 2;
    let labelAdjustHeight = 10;

    let maxValue = Math.max(...dataset);
    const svg = d3.select(this.barGraphchart.nativeElement)
      .append("svg")
      .attr("width", w)
      .attr("height", h);

    var svgDefs = svg.append('defs');
    var mainGradient = svgDefs.append('linearGradient')
      .attr('id', 'mainGradient' + this.graphId)
      .attr("x1", "0%")
      .attr("y1", "0%")
      .attr("x2", "0%")
      .attr("y2", "100%")
      .attr("spreadMethod", "pad");

    var custScale = d3.scaleLinear()
      .domain([1, colors.length])
      .range([0, 100]);

    colors.forEach((element, index, arr) => {
      mainGradient.append("svg:stop")
        .attr("stop-color", element)
        .attr("offset", custScale(index + 1) + "%");
    });

    let bars = svg.selectAll("rect")
      .data(dataset)
      .enter()
      .append("rect")
      .style('fill', 'url(#mainGradient' + this.graphId + ')')
      .attr("rx", w * 0.025)
      .attr("ry", w * 0.025)
      .attr("x", function (d, i) {
        return i * (w / dataset.length);
      })
      .attr("y", h)
      .attr("id", function (d, i) {
        return 'rect' + i;
      })
      .attr("width", function (d, i) {
        let x1 = i * (w / dataset.length);
        let x2 = (i + 1) * (w / dataset.length);
        return (x2 - x1) * 0.30;
      })
      .attr("height", h - 1)
      .on('mouseover', (d, i) => {
        d3.select('#rect' + i).attr("opacity", "0.7");
        this.showTemperature(d, i, w, h, dataset, labelAdjustWidth, maxValue, svg, finalLabelWidth, finalLabelHeight, labelFillColor, labelBorderColor, labelColor);
      })
      .on('mouseout', (d, i) => {
        d3.select('#rect' + i).attr("opacity", "1");
        this.hideTemperature();
      });

    bars.transition()
      .duration(1000)
      .delay(100)
      .attr("y", function (d) {
        return h - ((d / maxValue) * h) + finalLabelHeight + labelAdjustHeight;
      })
      .attr("height", function (d) {
        return ((d / maxValue) * h) - finalLabelHeight - labelAdjustHeight;
      });

    let lines = svg.selectAll("line")
      .data(dataset)
      .enter()
      .append("line")
      .style('stroke', lineColor)
      .attr('x1', function (d, i) {
        if (i === (dataset.length - 1)) {
          return;
        }
        let x1 = i * (w / dataset.length);
        let x2 = (i + 1) * (w / dataset.length);
        let barW = (x2 - x1) * 0.30;
        return (i * (w / dataset.length)) + (barW / 2);
      })
      .attr('y1', function (d, i) {
        if (i === (dataset.length - 1)) {
          return;
        }
        return h - ((d / maxValue) * h) + finalLabelHeight + labelAdjustHeight;
      })
      .attr('x2', function (d, i) {
        if (i === (dataset.length - 1)) {
          return;
        }
        let x1 = (i + 1) * (w / dataset.length);
        let x2 = (i + 2) * (w / dataset.length);
        let barW = (x2 - x1) * 0.30;
        return ((i + 1) * (w / dataset.length)) + (barW / 2);
      })
      .attr('y2', function (d, i) {
        if (i === (dataset.length - 1)) {
          return;
        }
        return h - ((dataset[i + 1] / maxValue) * h) + finalLabelHeight + labelAdjustHeight;
      });
  }

  showTemperature(d, i, w, h, dataset, labelAdjustWidth, maxValue, svg, finalLabelWidth,
    finalLabelHeight, labelFillColor, labelBorderColor, labelColor) {

    let x1 = i * (w / dataset.length) - labelAdjustWidth;
    let y1 = h - ((d / maxValue) * h);

    this.temperatureRect = svg
      .append("rect")
      .attr("x", (d) => {
        return i === 0 ? x1 + labelAdjustWidth : x1;
      })
      .attr("y", (d, i) => { return y1; })
      .attr("width", finalLabelWidth)
      .attr("height", finalLabelHeight)
      .style("fill", labelFillColor)
      .attr('stroke', labelBorderColor)
      .style("opacity", "1");

    this.temperatureText = svg.append('text')
      .attr("x", (d) => {
        return i === 0 ? x1 + labelAdjustWidth + 4 : x1 + 4;
      })
      .attr("y", (d, i) => { return y1 + (finalLabelHeight * 0.75); })
      .html(() => {
        return d + '&#176;F';
      })
      .style('fill', labelColor);
  }

  hideTemperature() {
    this.temperatureRect.remove();
    this.temperatureText.remove();
  }

}

