import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-linechart',
  templateUrl: './linechart.component.html',
  styleUrls: ['./linechart.component.scss']
})
export class LinechartComponent implements OnInit {
  @Input() public linechart;
  today = Date.now();
  constructor() { }
  ngOnInit() {
    console.log('linecharData:', this.linechart);
  }
}
