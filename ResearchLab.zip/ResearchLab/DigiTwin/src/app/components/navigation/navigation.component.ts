import { Component, OnInit } from '@angular/core';
import { FlexOffsetDirective } from '@angular/flex-layout';
import { ICountries } from 'src/app/interface/temprature';
import { DigitwinService } from 'src/app/services/digitwin.service';

@Component({
  selector: 'app-navigation',
  templateUrl: './navigation.component.html',
  styleUrls: ['./navigation.component.scss']
})
export class NavigationComponent implements OnInit {
  mobileNav: boolean = false;
  mobiledropDowns: boolean = false;
  selectedCountry = false;
  selectedState = false;
  selectedArea = false;
  selectedMeasure = false;
  public countries: ICountries;

  // country = [{
  //   CountryName: 'India',
  //   Measure: 'Temprature',
  //   States: [{
  //     StateName: 'Maharashtra',
  //     Cities: [
  //       'Pune',
  //       'Nagpur',
  //       'Mumbai'
  //     ]
  //   },
  //   {
  //     StateName: 'Kerala',
  //     Cities: [
  //       'Kochi',
  //       'Munnar'
  //     ]
  //   }
  //   ],
  // }];
  constructor(private service: DigitwinService) { }

  ngOnInit() {
    // this.getCountries();
  }
  toggleMobileNav() {
    this.mobiledropDowns = false;
    this.mobileNav = !this.mobileNav;
  }
  togglemobiledropDowns() {
    this.mobileNav = false;
    this.mobiledropDowns = !this.mobiledropDowns;
  }
  // changeDropValue(val) {
  //   if (val === 'country') {
  //     console.log(val);
  //     this.selectedCountry = true;
  //   }
  //   if (val === 'state') {
  //     console.log(val);
  //     this.selectedState = true;
  //   }
  //   if (val === 'measure') {
  //     console.log(val);
  //     this.selectedMeasure = true;
  //   }
  //   if (val === 'area') {
  //     console.log(val);
  //     this.selectedArea = true;
  //   }
  // }

  // getCountries() {
  //   this.service.getCountries().subscribe(
  //     data => { this.country = data; }
  //   )
  // }
}
