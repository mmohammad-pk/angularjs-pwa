import { Component, OnInit, Input, ElementRef, ViewChild } from '@angular/core';
import * as d3 from 'd3';
import { DigitwinService } from 'src/app/services/digitwin.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-device',
  templateUrl: './device.component.html',
  styleUrls: ['./device.component.scss']
})
export class DeviceComponent implements OnInit {
  public favourites: any = {};
  @ViewChild('doughnutWidth') doughnutWidth: ElementRef;
  @Input() data: any;
  constructor(private service: DigitwinService, private route: Router) { }
  ngOnInit() {
    this.getWidth()
  }

  onDeviceFavourite(id) {
    if (this.favourites[id]) {
      delete this.favourites[id];
    } else {
      this.favourites[id] = true;
    }
  }
  getWidth() {
    console.log(this.doughnutWidth.nativeElement.offsetWidth)
    return this.doughnutWidth.nativeElement.offsetWidth;
  }


  getZone(temperature) {
    const scaleTemp = d3.scaleLinear().domain([20, 70]).range([0, 2 * Math.PI]);
    const angle = scaleTemp(temperature);
    if (angle >= 0 && angle <= Math.PI / 2) {
      return 'Cold Zone';
    } else if (angle > Math.PI / 2 && angle <= Math.PI) {
      return 'Safe Zone';
    } else if (angle > Math.PI && angle <= (Math.PI * 3 / 2)) {
      return 'Warning Zone';
    } else if (angle > (Math.PI * 3 / 2) && angle <= (2 * Math.PI)) {
      return 'Critical Zone';
    }
  }
  getDevice(deviceData) {
    this.service.setDeviceData(deviceData);
    this.route.navigate(['/AlarmQuickView']);
  }
}
