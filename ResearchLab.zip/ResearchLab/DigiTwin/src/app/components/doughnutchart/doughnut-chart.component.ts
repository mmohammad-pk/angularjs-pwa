import { Component, OnInit, Input, ViewChild, ElementRef } from '@angular/core';
import * as d3 from 'd3';
import * as chroma from 'chroma-js';
import { Router } from '@angular/router';
import { DigitwinService } from 'src/app/services/digitwin.service';


@Component({
  selector: 'app-doughnut-chart',
  templateUrl: './doughnut-chart.component.html',
  styleUrls: ['./doughnut-chart.component.scss']
})
export class DoughnutChartComponent implements OnInit {
  // chartKeys = Object.keys;
  // chartData = { chart1: 1, chart2 : 2 }

  @Input()
  public temperature;
  @ViewChild('doughnut') doughnut: ElementRef;

  @Input('graphWidth') graphWidth;


  constructor(private route: Router, private service: DigitwinService) { }

  ngOnInit() {
    this.initChart();
  }

  initChart() {
    const temperature = this.temperature;
    const height = window.screen.width * (this.graphWidth / 100);

    const scaleTemp = d3.scaleLinear().domain([20, 70]).range([0, 2 * Math.PI]);

    const request = [{ startAngle: scaleTemp(temperature), endAngle: scaleTemp(temperature), label: '' + temperature }];
    const areaData = [this.getAreaQuarter(scaleTemp(temperature))];

    const width = height;
    const radius = height * 0.3;
    const areaRadiusOuter = height * 0.315;
    const areaRadiusInner = height * 0.31;
    const hole = radius * 0.4;
    const labelRadius = height * 0.70;

    // const colArray = ['#0071ff', '#770087', '#ff0000', '#ff6300', '#ffcc00', '#9acc00', '#42ad0d', '#0071ff'];
    const colArray = ['#0071ff', '#2A9765', '#42ad0d', '#DDC602', '#ffcc00', '#FF6F00', '#ff0000', '#0071ff'];
    const scale = chroma.scale(colArray).colors(472);


    const svg = d3.select(this.doughnut.nativeElement)
      .append('svg')
      .attr('class', 'gradient-pie')
      .attr('width', width)
      .attr('height', height);

    const arcFill = svg.append('g')
      .attr('transform', 'translate(' + width / 2 + ',' + width / 2 + ')');

    const arcOutline = svg.append('g')
      .attr('transform', 'translate(' + width / 2 + ',' + width / 2 + ')');

    const lineSvg = svg.append('g')
      .attr('transform', 'translate(' + width / 2 + ',' + width / 2 + ')')
      .attr('class', 'casing');

    const areaSvg = svg.append('g')
      .attr('transform', 'translate(' + width / 2 + ',' + width / 2 + ')')
      .attr('class', 'area');

    const borderSvg = svg.append('g')
      .attr('transform', 'translate(' + width / 2 + ',' + width / 2 + ')')
      .attr('class', 'border');

    const percentFormat = d3.format(',.2%');

    const labelSvg = svg.append('g')
      .attr('transform', 'translate(' + width / 2 + ',' + width / 2 + ')')
      .attr('class', 'labelName');

    const linesSvg = svg.append('g')
      .attr('transform', 'translate(' + width / 2 + ',' + width / 2 + ')')
      .attr('class', 'lines');

    const iconSvg = svg.append('g')
      .attr('transform', 'translate(' + width / 2 + ',' + width / 2 + ')')
      .attr('class', 'icon');

    const arc = d3.arc()
      .innerRadius(hole)
      .outerRadius(radius);

    const areaArc = d3.arc()
      .innerRadius(hole)
      .outerRadius(radius);

    const borderArc = d3.arc()
      .innerRadius(areaRadiusInner)
      .outerRadius(areaRadiusOuter);

    const labelArc = d3.arc()
      .outerRadius(labelRadius)
      .innerRadius(0);

    const lineArc = d3.arc()
      .outerRadius(labelRadius)
      .innerRadius(0);

    const pie = d3.pie()
      .sort(null)
      .value((d) => {
        return d;
      });

    const data = [{ startAngle: 0, endAngle: 2 * Math.PI }];

    arcOutline.selectAll('.arc')
      .data(data)
      .enter()
      .append('path')
      .attr('class', 'arc')
      .attr('d', arc)
      .style('fill', (d) => {
        return this.createGradient(d, arcFill, arc, scale)
      });

    areaSvg.selectAll('.area')
      .data(areaData)
      .enter()
      .append('path')
      .attr('class', 'area')
      .attr('d', areaArc)
      .style('fill', 'white')
      .style('opacity', '0.15');

    borderSvg.selectAll('.border')
      .data(areaData)
      .enter()
      .append('path')
      .attr('class', 'border')
      .attr('d', borderArc)
      .style('fill', 'white');

    //Finding the x and y cordinates for label background
    const rectWidth = 40;
    const rectHeight = 20;
    const lineExt = 20;
    const coOrdinates = [];
    for (const each of request) {
      const pos = labelArc.centroid(each);
      let x: any = 0;
      let y: any = 0;
      if (this.midAngle(each) < Math.PI) {
        x = pos[0] + lineExt;
        y = pos[1] - (rectHeight / 2);
      } else {
        x = pos[0] - lineExt - (rectWidth);
        y = pos[1] - (rectHeight / 2);
      }
      coOrdinates.push([x, y]);
    }

    labelSvg
      .append('rect')
      .attr('x', () => { return coOrdinates[0][0]; })
      .attr('y', () => { return coOrdinates[0][1]; })
      .attr('rx', '5')
      .attr('ry', '5')
      .attr('width', (d) => { return rectWidth; })
      .attr('height', (d) => { return rectHeight; })
      .style('fill', '#fffdd0')
      .style('opacity', '0.9');

    labelSvg.append('image')
      .attr('href', '/assets/images/therm.svg')
      .attr('width', 13)
      .attr('height', 13)
      .attr('x', coOrdinates[0][0])
      .attr('y', coOrdinates[0][1] + 4);

    labelSvg.selectAll('.labelName')
      .data(request)
      .enter().append('text')
      .attr('dy', '.35em')
      .html((d) => {
        return d.label + '&#176;F';
      })
      .attr('transform', (d) => {
        const pos = labelArc.centroid(d);
        return 'translate(' + pos + ')';
      })
      .attr('dx', (d) => {
        if (this.midAngle(d) < Math.PI) {
          return '' + (lineExt + 12);
        } else {
          return '-' + (lineExt + 5);
        }
      })
      .style('fill', 'black')
      .style('text-anchor', (d) => {
        return (this.midAngle(d)) < Math.PI ? 'start' : 'end';
      });

    linesSvg.selectAll('.lines')
      .data(request)
      .enter().append('polyline')
      .attr('points', (d) => {
        const pos = labelArc.centroid(d);
        const extra = this.midAngle(d) < Math.PI ? [pos[0] + 20, pos[1]] : [pos[0] - 20, pos[1]];
        return [[0, 0], pos, extra]
      });

    const colorRange = ['#429321', '#45ae0c', '#86c502']
    const color = d3.scaleLinear().range(colorRange).domain([-1, 0, 1]);

    const radialGradient = iconSvg.append('defs')
      .append('radialGradient')
      .attr('id', 'radial-gradient');

    radialGradient.append('stop')
      .attr('offset', '0%')
      .attr('stop-color', color(-1));

    radialGradient.append('stop')
      .attr('offset', '50%')
      .attr('stop-color', color(0));

    radialGradient.append('stop')
      .attr('offset', '100%')
      .attr('stop-color', color(1));

    iconSvg.append('circle')
      .attr('r', hole * 0.6)
      .style('opacity', 1.0)
      .style('fill', 'url(#radial-gradient)');

    iconSvg.append('image')
      .attr('href', '/assets/images/watchout.svg')
      .attr('width', hole * 0.6)
      .attr('height', hole * 0.6)
      .attr('x', -(hole * 0.6) / 2)
      .attr('y', -(hole * 0.6) / 2);

    const w = radius;
    const h = radius;
    const mt = 20;
    const mr = 20;
    const mb = 20;
    const ml = 20;
    const f = 20;
    const tickCount = 60;
    const r = hole;

    const casing = d3.select('.casing');

    const step = 360 / tickCount;
    for (let i = 0; i < 60; i++) {
      // classify ticks
      let tickClass = '';
      let tickSize = 0;
      if (i % 2 === 0) {
        tickClass = 'tick main';
        tickSize = height * 0.015;
      } else {
        tickClass = 'tick';
        tickSize = height * 0.01;
      }
      // get the angle in radians
      const phi = i * step * Math.PI / 180;
      // compute start/end coordinates for ticks
      const x1 = (r - tickSize - 2) * Math.cos(phi);
      const x2 = (r - 2) * Math.cos(phi);
      const y1 = (r - tickSize - 2) * Math.sin(phi);
      const y2 = (r - 2) * Math.sin(phi);

      casing.append('line')
        .attr('x1', x1)
        .attr('y1', y1)
        .attr('x2', x2)
        .attr('y2', y2)
        .attr('class', tickClass);
    }
  }

  getAreaQuarter(angle) {
    if (angle >= 0 && angle <= Math.PI / 2) {
      return { startAngle: 0, endAngle: Math.PI * 0.5 };
    } else if (angle > Math.PI / 2 && angle <= Math.PI) {
      return { startAngle: Math.PI / 2, endAngle: Math.PI };
    } else if (angle > Math.PI && angle <= (Math.PI * 3 / 2)) {
      return { startAngle: Math.PI, endAngle: (Math.PI * 3 / 2) };
    } else if (angle > (Math.PI * 3 / 2) && angle <= (2 * Math.PI)) {
      return { startAngle: (Math.PI * 3 / 2), endAngle: 2 * Math.PI };
    }
  }

  midAngle(d) { return d.startAngle + (d.endAngle - d.startAngle) / 2; }

  createGradient(d, arcFill, arc, scale) {
    const miniArcs = []
    const angleExtent = d.endAngle - d.startAngle
    const noOfArcs = angleExtent * 75 //seems like a good number
    const miniArcAngle = angleExtent / noOfArcs
    for (let j = 0; j < noOfArcs; j++) {
      const miniArc: any = {};
      miniArc.startAngle = d.startAngle + (miniArcAngle * j)
      //0.01 so the colours overlap slightly, so there's no funny artefacts. 
      miniArc.endAngle = miniArc.startAngle + miniArcAngle + 0.01
      //unless it goes beyond the end of the parent arc
      miniArc.endAngle = miniArc.endAngle > d.endAngle ? d.endAngle : miniArc.endAngle
      miniArcs.push(miniArc)
    }
    arcFill.selectAll('.mini-arc')
      .data(miniArcs)
      .enter()
      .append('g')
      .append('path')
      .attr('id', (a, i) => {
        return i;
      })
      .attr('class', 'arc')
      .attr('d', arc)
      .attr('opacity', 5)
      .style('fill', (a, i) => {
        return scale[i];
      });
    return 'none';
  }

}
