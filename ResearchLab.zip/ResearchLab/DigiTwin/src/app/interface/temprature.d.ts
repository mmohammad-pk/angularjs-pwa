export class ITemprature {
    tankName: string;
    location: string;
    currentTemperature: number;
    yesterdayTemperature: number;
    week: Iweek;
    month: Imonth;
}

export class Iweek {
    weekAvg: number;
    dailyAvg: Array<IdailyAvg>;
    dailyLows: Array<IdailyLow>;
    dailyHigh: Array<IdailyHigh>
}
export class IdailyAvg {
    date: string;
    dAvgTemp: number;
}
export class IdailyLow {
    date: string;
    lowTemp: number;
}
export class IdailyHigh {
    date: string;
    highTemp: number;
}
export class Imonth {
    monthAvg: number;
    weeklyAvg: Array<IweeklyAvg>
}
export class IweeklyAvg {
    week: number;
}


export class IAlarms {
    tankname: string;
    area: string;
    temprature: number;
    status: string;
    previous: number;
    date: string;
    time: string;
}
export class ICountries {
    CountryName: string;
    Measure: string;
    States: Array<IStates>;
}
export class IStates {
    StateName: string;
    Cities: Array<any>;
}
