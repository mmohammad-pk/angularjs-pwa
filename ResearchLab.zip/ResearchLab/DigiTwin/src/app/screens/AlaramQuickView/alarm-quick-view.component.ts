import { Component, OnInit, Input, ViewChild, ElementRef } from '@angular/core';
import { DigitwinService } from 'src/app/services/digitwin.service';
// import * as d3 from 'd3';
// import * as chroma from 'chroma-js';

@Component({
  selector: 'app-alarm-quick-view',
  templateUrl: './alarm-quick-view.component.html',
  styleUrls: ['./alarm-quick-view.component.scss']
})
export class AlarmQuickViewComponent implements OnInit {
  month = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'];
  private deviceData;
  public favourites: any = {};
  public panelExpand = false;
  public yesterDayAvgTempBar = false;
  public weekAvgTempBar = false;
  public monthAvgTempBar = false;
  //@ViewChild('quickviewchart') quickviewchart: ElementRef;
  @ViewChild('barChart') barChart: ElementRef;
  @ViewChild('weekBarChart') weekBarChart: ElementRef;
  @ViewChild('monthBarChart') monthBarChart: ElementRef;
  @ViewChild('monthBarChart2') monthBarChart2: ElementRef;




  constructor(private service: DigitwinService) { }

  ngOnInit() {
    this.getQuickViewDevice();
  }
  // getQuickViewDoughnutWidth() {
  //   return this.quickviewchart.nativeElement.offsetWidth;
  // }

  getQuickViewDevice() {
    this.deviceData = this.service.getDeviceData();
  }

  onDeviceFavourite(id) {
    if (this.favourites[id]) {
      delete this.favourites[id];
    } else {
      this.favourites[id] = true;
    }
  }
  accordionToggle() {
    this.panelExpand = !this.panelExpand;
  }
  accordionYesterdayAvg() {
    this.yesterDayAvgTempBar = !this.yesterDayAvgTempBar;
  }
  accordionWeekAvg() {
    this.weekAvgTempBar = !this.weekAvgTempBar;
  }
  accordionMonthAvg() {
    this.monthAvgTempBar = !this.monthAvgTempBar;
  }

  dailyAvgData() {
    return this.deviceData.week.dailyAvg.map((item) => { return item.dAvgTemp; })
  }
  weekAvgData() {
    return this.deviceData.month.weeklyAvg;
  }


  getChartWidth(e) {
    if (this.barChart && this.barChart.nativeElement && this.barChart.nativeElement.offsetWidth) {
      return this.barChart.nativeElement.offsetWidth;
    }
    return 0;
  }
  getWeekChartWidth(e) {
    if (this.weekBarChart && this.weekBarChart.nativeElement && this.weekBarChart.nativeElement.offsetWidth) {
      return this.weekBarChart.nativeElement.offsetWidth * 0.70;
    }
    return 0;
  }
  getMonthChartWidth(e) {
    if (this.monthBarChart && this.monthBarChart.nativeElement && this.monthBarChart.nativeElement.offsetWidth) {
      return this.monthBarChart.nativeElement.offsetWidth;
    }
    return 0;
  }
  getMonthAvgChartWidth(e) {
    if (this.monthBarChart2 && this.monthBarChart2.nativeElement && this.monthBarChart2.nativeElement.offsetWidth) {
      return this.monthBarChart2.nativeElement.offsetWidth * 0.70;
    }
    return 0;
  }

}

