import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AlarmQuickViewComponent } from './alarm-quick-view.component';

describe('AlarmQuickViewComponent', () => {
  let component: AlarmQuickViewComponent;
  let fixture: ComponentFixture<AlarmQuickViewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AlarmQuickViewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AlarmQuickViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
