import { Component, OnInit } from '@angular/core';
import { ITemprature } from 'src/app/interface/temprature';
import { DigitwinService } from 'src/app/services/digitwin.service';
import * as d3 from 'd3';
import { Router } from '@angular/router';
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {
  public temperatureData: any;

  constructor(public service: DigitwinService, private route: Router) { }

  ngOnInit() {
    this.getDoughnutChartData();
  }

  getDoughnutChartData() {
    this.service.getTemprature().subscribe(
      data => {
        this.temperatureData = data;
        console.log("temp", this.temperatureData);
      }
    );
  }
  // getDevice(device) {
  //   this.service.setDeviceData(device);
  //   this.route.navigate(['/AlarmQuickView']);
  // }

}
