import { Component, OnInit } from '@angular/core';
import { DigitwinService } from 'src/app/services/digitwin.service';


@Component({
  selector: 'app-area-wise-alarm',
  templateUrl: './area-wise-alarm.component.html',
  styleUrls: ['./area-wise-alarm.component.scss']
})
export class AreaWiseAlarmComponent implements OnInit {
  public temperatureData: any;
  constructor(private service: DigitwinService) { }

  ngOnInit() { this.getData() }
  // private getData = () => this.service.getTemprature().subscribe(this.onSuccess);
  getData() {
    this.service.getTemprature().subscribe(this.onSuccess);
  }

  private onSuccess = data => this.temperatureData = data;

}
