import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AreaWiseAlarmComponent } from './area-wise-alarm.component';

describe('AreaWiseAlarmComponent', () => {
  let component: AreaWiseAlarmComponent;
  let fixture: ComponentFixture<AreaWiseAlarmComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AreaWiseAlarmComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AreaWiseAlarmComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
